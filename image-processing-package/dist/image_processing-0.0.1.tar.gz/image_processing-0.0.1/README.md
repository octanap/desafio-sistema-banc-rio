# image_processing

Description. 
The package image_processing is used to:
Processing:
	- histogram matching
	- structural similarity
	- resize image
Utils:
    - read image
	- save image
	- plot image
	- plot result
	- plot histogram



## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install image_processing
```

## Author
My_name

## License
[MIT](https://choosealicense.com/licenses/mit/)